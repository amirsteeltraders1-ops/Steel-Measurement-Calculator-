(function() {
  'use strict';

  // DOM elements
  const modePcs = document.getElementById('modePcs');
  const modeBheem = document.getElementById('modeBheem');
  const pcsSection = document.getElementById('pcsInputs');
  const bheemSection = document.getElementById('bheemInputs');
  const customerName = document.getElementById('customerName');
  const projectPlot = document.getElementById('projectPlot');
  const dateDisplay = document.getElementById('dateDisplay');
  const addBtn = document.getElementById('addItemBtn');
  const itemsListDiv = document.getElementById('itemsList');
  const totalLengthSpan = document.getElementById('totalLength');
  const totalBarsSpan = document.getElementById('totalBars');
  const totalWeightSpan = document.getElementById('totalWeight');
  const whatsappBtn = document.getElementById('whatsappBtn');
  const pdfBtn = document.getElementById('pdfBtn');
  const copyBtn = document.getElementById('copyBtn');
  const clearListBtn = document.getElementById('clearListBtn');
  const historyListDiv = document.getElementById('historyList');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');

  // PDF Dialog elements
  const pdfDialog = document.getElementById('pdfDialog');
  const openPdfBtn = document.getElementById('openPdfBtn');
  const sharePdfBtn = document.getElementById('sharePdfBtn');
  const cancelPdfBtn = document.getElementById('cancelPdfBtn');

  // State
  let currentMode = 'pcs';
  let items = [];
  let history = [];

  // localStorage keys
  const STORAGE_ITEMS = 'steelItems';
  const STORAGE_HISTORY = 'steelHistory';

  // Weight per foot for each rebar size (kg)
  const WEIGHT_PER_FOOT = {
    '#3': 0.170,
    '#4': 0.300,
    '#6': 0.680,
    '#8': 1.200
  };

  // Today's date
  const today = new Date().toLocaleDateString('en-IN', { year:'numeric', month:'2-digit', day:'2-digit' });
  dateDisplay.textContent = today;

  // Populate dropdowns
  function populateSelect(selectId, start, end, defaultVal) {
    const select = document.getElementById(selectId);
    select.innerHTML = '';
    for (let i = start; i <= end; i++) {
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = i;
      select.appendChild(opt);
    }
    if (defaultVal !== undefined) select.value = defaultVal;
  }
  
  // PCS dropdowns
  populateSelect('pcsFeetSelect', 1, 40, 1);
  populateSelect('pcsInchesSelect', 0, 11, 0);
  populateSelect('pcsQtySelect', 1, 100, 1);
  
  // BHEEM dropdowns (same as PCS)
  populateSelect('bheemLenFtSelect', 1, 40, 15);
  populateSelect('bheemLenInSelect', 0, 11, 0);

  // Auto‑clear logic for combo inputs
  function setupAutoClear(selectId, manualId) {
    const sel = document.getElementById(selectId);
    const man = document.getElementById(manualId);
    if (!sel || !man) return;
    sel.addEventListener('change', () => { man.value = ''; });
    man.addEventListener('focus', () => { sel.selectedIndex = -1; });
    man.addEventListener('input', () => { if (man.value !== '') sel.selectedIndex = -1; });
  }
  
  // PCS auto-clear
  setupAutoClear('pcsFeetSelect', 'pcsFeetManual');
  setupAutoClear('pcsInchesSelect', 'pcsInchesManual');
  setupAutoClear('pcsQtySelect', 'pcsQtyManual');
  
  // BHEEM auto-clear
  setupAutoClear('bheemLenFtSelect', 'bheemLenFtManual');
  setupAutoClear('bheemLenInSelect', 'bheemLenInManual');

  // Rebar button groups
  function initRebarGroup(containerId, defaultSize) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const btns = container.querySelectorAll('.rebar-btn');
    btns.forEach(btn => {
      btn.addEventListener('click', function(e) {
        btns.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
      });
      if (btn.dataset.size === defaultSize) btn.classList.add('active');
    });
  }
  initRebarGroup('pcsRebarGroup', '#4');
  initRebarGroup('bheemRebar1Group', '#3');
  initRebarGroup('bheemRebar2Group', '#4');

  // Mode toggle
  function setMode(mode) {
    currentMode = mode;
    if (mode === 'pcs') {
      modePcs.classList.add('active');
      modeBheem.classList.remove('active');
      pcsSection.classList.remove('hidden');
      bheemSection.classList.add('hidden');
    } else {
      modeBheem.classList.add('active');
      modePcs.classList.remove('active');
      bheemSection.classList.remove('hidden');
      pcsSection.classList.add('hidden');
    }
  }
  modePcs.addEventListener('click', () => setMode('pcs'));
  modeBheem.addEventListener('click', () => setMode('bheem'));

  // Get active size
  function getActiveSize(containerId) {
    const active = document.querySelector(`#${containerId} .rebar-btn.active`);
    return active ? active.dataset.size : '#4';
  }

  // Helper to get value from combo (dropdown or manual)
  function getComboValue(selectId, manualId, min, max, name) {
    let select = document.getElementById(selectId);
    let manual = document.getElementById(manualId);
    let val = manual.value;
    if (val === '') {
      if (select.selectedIndex === -1) {
        alert(`Enter ${name} (dropdown or manual)`);
        return null;
      }
      val = select.value;
    }
    val = parseInt(val, 10);
    if (isNaN(val) || val < min || val > max) {
      alert(`${name} must be ${min}-${max}`);
      return null;
    }
    return val;
  }

  // Add item
  function addItem() {
    if (currentMode === 'pcs') {
      // Feet
      const feet = getComboValue('pcsFeetSelect', 'pcsFeetManual', 1, 40, 'Feet');
      if (feet === null) return;
      
      // Inches
      const inches = getComboValue('pcsInchesSelect', 'pcsInchesManual', 0, 11, 'Inches');
      if (inches === null) return;
      
      // Quantity
      const qty = getComboValue('pcsQtySelect', 'pcsQtyManual', 1, Infinity, 'Quantity');
      if (qty === null) return;

      const size = getActiveSize('pcsRebarGroup');

      items.push({ type: 'pcs', feet, inches, quantity: qty, size });
    } else { // BHEEM
      // Bheem Count
      const count = parseInt(document.getElementById('bheemCount').value, 10);
      if (isNaN(count) || count < 1) { alert('Bheem count ≥1'); return; }
      
      // Length Feet
      const lenFt = getComboValue('bheemLenFtSelect', 'bheemLenFtManual', 1, 40, 'Length feet');
      if (lenFt === null) return;
      
      // Length Inches
      const lenIn = getComboValue('bheemLenInSelect', 'bheemLenInManual', 0, 11, 'Length inches');
      if (lenIn === null) return;
      
      // Pieces
      const pieces = parseInt(document.getElementById('bheemPieces').value, 10);
      if (isNaN(pieces) || pieces < 1) { alert('Pieces ≥1'); return; }
      
      // Ring
      const ring = document.getElementById('bheemRing').value.trim();
      if (!ring) { alert('Enter ring size'); return; }

      const size1 = getActiveSize('bheemRebar1Group');
      const qty1 = parseInt(document.getElementById('bheemQty1').value, 10);
      if (isNaN(qty1) || qty1 < 0) { alert('First quantity must be 0 or more'); return; }
      
      const size2 = getActiveSize('bheemRebar2Group');
      const qty2 = parseInt(document.getElementById('bheemQty2').value, 10);
      if (isNaN(qty2) || qty2 < 0) { alert('Second quantity must be 0 or more'); return; }
      
      if (qty1 + qty2 === 0) { alert('At least one quantity must be greater than 0'); return; }

      items.push({ type: 'bheem', count, lenFt, lenIn, pieces, ring, size1, qty1, size2, qty2 });
    }

    saveItems();
    renderAll();
  }
  addBtn.addEventListener('click', addItem);

  // Remove item
  function removeItem(index) {
    items.splice(index, 1);
    saveItems();
    renderAll();
  }

  // Calculate totals
  function calcTotals() {
    let totalInches = 0;
    let totalBars = 0;
    let totalWeight = 0;

    items.forEach(item => {
      if (item.type === 'pcs') {
        const lengthInches = (item.feet * 12 + item.inches);
        totalInches += lengthInches * item.quantity;
        totalBars += item.quantity;
        const totalFeet = lengthInches / 12 * item.quantity;
        totalWeight += totalFeet * WEIGHT_PER_FOOT[item.size];
      } else { // bheem
        const lengthInches = (item.lenFt * 12 + item.lenIn);
        const barsThisItem = item.count * (item.qty1 + item.qty2);
        totalInches += lengthInches * barsThisItem;
        totalBars += barsThisItem;
        
        const feetPerBar = lengthInches / 12;
        const totalFeet1 = feetPerBar * item.count * item.qty1;
        const totalFeet2 = feetPerBar * item.count * item.qty2;
        totalWeight += totalFeet1 * WEIGHT_PER_FOOT[item.size1] + totalFeet2 * WEIGHT_PER_FOOT[item.size2];
      }
    });

    const feet = Math.floor(totalInches / 12);
    const inches = totalInches % 12;
    return { feet, inches, totalBars, totalWeight };
  }

  // Render items list
  function renderItems() {
    if (items.length === 0) { 
      itemsListDiv.innerHTML = '<div style="text-align:center; color:#888; padding:20px;">➕ No items yet</div>'; 
      return; 
    }
    let html = '';
    items.forEach((item, idx) => {
      let text = '';
      if (item.type === 'pcs') {
        text = `${item.feet}' ${item.inches}" = ${item.quantity} ${item.size}`;
      } else {
        if (item.qty2 === 0) {
          text = `${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty1} ${item.size1} Ring ${item.ring}`;
        } else if (item.qty1 === 0) {
          text = `${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty2} ${item.size2} Ring ${item.ring}`;
        } else {
          text = `${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty1} ${item.size1} & ${item.qty2} ${item.size2} Ring ${item.ring}`;
        }
      }
      html += `<div class="item-row"><span class="item-text">${text}</span><button class="remove-item" data-index="${idx}">✖</button></div>`;
    });
    itemsListDiv.innerHTML = html;
    document.querySelectorAll('.remove-item').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = e.target.dataset.index;
        if (idx !== undefined) removeItem(parseInt(idx,10));
      });
    });
  }

  // Render totals
  function renderTotals() {
    const { feet, inches, totalBars, totalWeight } = calcTotals();
    totalLengthSpan.textContent = `${feet}' ${inches}"`;
    totalBarsSpan.textContent = totalBars;
    totalWeightSpan.textContent = totalWeight.toFixed(2);
  }

  // Save / load
  function saveItems() {
    localStorage.setItem(STORAGE_ITEMS, JSON.stringify(items));
  }
  function loadItems() {
    const saved = localStorage.getItem(STORAGE_ITEMS);
    if (saved) { try { items = JSON.parse(saved); } catch(e){ items=[]; } }
  }

  // History
  function saveHistory() {
    localStorage.setItem(STORAGE_HISTORY, JSON.stringify(history.slice(0,20)));
  }
  function loadHistory() {
    const saved = localStorage.getItem(STORAGE_HISTORY);
    if (saved) { try { history = JSON.parse(saved); } catch(e){ history=[]; } }
  }

  function pushCurrentToHistory() {
    if (items.length === 0) return;
    const timestamp = new Date().toLocaleString();
    const label = `${timestamp} (${items.length} items)`;
    history.unshift({ timestamp, items: JSON.parse(JSON.stringify(items)), label });
    if (history.length > 20) history.pop();
    saveHistory();
    renderHistory();
  }

  function renderHistory() {
    if (history.length === 0) { historyListDiv.innerHTML = '<div style="color:#aaa; padding:8px;">Empty</div>'; return; }
    let h = '';
    history.forEach((entry, idx) => {
      h += `<div class="history-item" data-history-index="${idx}"><span>📌 ${entry.label}</span> <span style="color:#1e3c72;">↻</span></div>`;
    });
    historyListDiv.innerHTML = h;
    document.querySelectorAll('.history-item').forEach(el => {
      el.addEventListener('click', () => {
        const idx = el.dataset.historyIndex;
        if (idx !== undefined) {
          items = JSON.parse(JSON.stringify(history[idx].items));
          saveItems();
          renderAll();
        }
      });
    });
  }

  // Clear list (saves to history)
  function clearList() {
    if (items.length > 0) pushCurrentToHistory();
    items = [];
    saveItems();
    renderAll();
  }

  // Generate PDF
  function generatePDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    let y = 20;
    doc.setFontSize(16);
    doc.text('Steel Notepad Report', 20, y);
    y += 10;
    
    doc.setFontSize(12);
    const cust = customerName.value.trim() || 'Customer';
    const proj = projectPlot.value.trim() || 'Project';
    doc.text(`Customer: ${cust}`, 20, y);
    y += 7;
    doc.text(`Project: ${proj}`, 20, y);
    y += 7;
    doc.text(`Date: ${today}`, 20, y);
    y += 10;
    
    doc.text('Items:', 20, y);
    y += 7;
    
    items.forEach((item, i) => {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      let text = '';
      if (item.type === 'pcs') {
        text = `${i+1}. ${item.feet}' ${item.inches}" = ${item.quantity} ${item.size}`;
      } else {
        if (item.qty2 === 0) {
          text = `${i+1}. ${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty1} ${item.size1} Ring ${item.ring}`;
        } else if (item.qty1 === 0) {
          text = `${i+1}. ${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty2} ${item.size2} Ring ${item.ring}`;
        } else {
          text = `${i+1}. ${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty1} ${item.size1} & ${item.qty2} ${item.size2} Ring ${item.ring}`;
        }
      }
      doc.text(text, 25, y);
      y += 7;
    });
    
    y += 5;
    const { feet, inches, totalBars, totalWeight } = calcTotals();
    doc.text(`Total Length: ${feet}' ${inches}"`, 20, y);
    y += 7;
    doc.text(`Total Bars: ${totalBars}`, 20, y);
    y += 7;
    doc.text(`Total Weight: ${totalWeight.toFixed(2)} kg`, 20, y);
    
    return doc;
  }

  // PDF Dialog functions
  function showPdfDialog() {
    pdfDialog.style.display = 'flex';
  }

  function hidePdfDialog() {
    pdfDialog.style.display = 'none';
  }

  pdfBtn.addEventListener('click', () => {
    if (items.length === 0) {
      alert('No items to generate PDF');
      return;
    }
    showPdfDialog();
  });

  openPdfBtn.addEventListener('click', () => {
    hidePdfDialog();
    const doc = generatePDF();
    doc.output('dataurlnewwindow');
  });

  sharePdfBtn.addEventListener('click', () => {
    hidePdfDialog();
    const doc = generatePDF();
    const pdfBlob = doc.output('blob');
    const file = new File([pdfBlob], 'steel_notepad.pdf', { type: 'application/pdf' });
    
    if (navigator.share) {
      navigator.share({
        title: 'Steel Notepad Report',
        files: [file]
      }).catch(err => {
        if (err.name !== 'AbortError') {
          alert('Sharing failed: ' + err.message);
        }
      });
    } else {
      // Fallback for browsers that don't support sharing
      doc.save('steel_notepad.pdf');
      alert('PDF saved. You can share it manually.');
    }
  });

  cancelPdfBtn.addEventListener('click', hidePdfDialog);

  // Close dialog when clicking outside
  pdfDialog.addEventListener('click', (e) => {
    if (e.target === pdfDialog) {
      hidePdfDialog();
    }
  });

  // Share text
  function getShareText() {
    const cust = customerName.value.trim() || 'Customer';
    const proj = projectPlot.value.trim() || 'Project';
    let text = `🏗️ STEEL NOTEPAD\n👤 ${cust} | ${proj} | ${today}\n\n`;
    items.forEach((item, i) => {
      if (item.type === 'pcs') {
        text += `${i+1}. ${item.feet}' ${item.inches}" = ${item.quantity} ${item.size}\n`;
      } else {
        if (item.qty2 === 0) {
          text += `${i+1}. ${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty1} ${item.size1} Ring ${item.ring}\n`;
        } else if (item.qty1 === 0) {
          text += `${i+1}. ${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty2} ${item.size2} Ring ${item.ring}\n`;
        } else {
          text += `${i+1}. ${item.count} x Bheem ${item.lenFt}' ${item.lenIn}" ${item.qty1} ${item.size1} & ${item.qty2} ${item.size2} Ring ${item.ring}\n`;
        }
      }
    });
    const { feet, inches, totalBars, totalWeight } = calcTotals();
    text += `\n📏 Length: ${feet}' ${inches}"   🔗 Bars: ${totalBars}   ⚖️ Weight: ${totalWeight.toFixed(2)} kg`;
    return text;
  }

  // Action buttons
  whatsappBtn.addEventListener('click', () => {
    const txt = encodeURIComponent(getShareText());
    window.open(`https://wa.me/?text=${txt}`, '_blank');
  });

  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(getShareText()).then(() => alert('📋 Copied!')).catch(() => alert('Copy failed'));
  });

  clearListBtn.addEventListener('click', clearList);

  clearHistoryBtn.addEventListener('click', () => {
    history = [];
    saveHistory();
    renderHistory();
  });

  // Render all
  function renderAll() {
    renderItems();
    renderTotals();
    renderHistory();
  }

  // Initial load
  loadItems();
  loadHistory();
  renderAll();
  setMode('pcs');
})();